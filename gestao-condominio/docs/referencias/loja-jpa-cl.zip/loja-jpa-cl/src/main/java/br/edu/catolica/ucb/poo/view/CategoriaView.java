package br.edu.catolica.ucb.poo.view;

import br.edu.catolica.ucb.poo.model.Categoria;
import br.edu.catolica.ucb.poo.service.CategoriaService;

import java.util.List;

public class CategoriaView {

    private final Console console;
    private final CategoriaService service = new CategoriaService();

    public CategoriaView(Console console) {
        this.console = console;
    }

    public void exibir() {
        int opcao;
        do {
            console.titulo("CATEGORIAS");
            System.out.println("1 - Listar");
            System.out.println("2 - Cadastrar");
            System.out.println("3 - Atualizar");
            System.out.println("4 - Excluir");
            System.out.println("0 - Voltar");
            opcao = console.lerInteiro("Opcao: ");
            executar(opcao);
        } while (opcao != 0);
    }

    private void executar(int opcao) {
        try {
            switch (opcao) {
                case 1 -> listar();
                case 2 -> cadastrar();
                case 3 -> atualizar();
                case 4 -> excluir();
                case 0 -> { }
                default -> console.erro("Opcao invalida.");
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            console.erro(e.getMessage());
        } catch (RuntimeException e) {
            console.erro("Falha ao acessar o banco de dados: " + e.getMessage());
        }
    }

    public void listar() {
        List<Categoria> categorias = service.listar();
        if (categorias.isEmpty()) {
            System.out.println("Nenhuma categoria cadastrada.");
            return;
        }
        categorias.forEach(System.out::println);
    }

    private void cadastrar() {
        String nome = console.lerTexto("Nome: ");
        Categoria categoria = service.cadastrar(nome);
        console.sucesso("Categoria cadastrada: " + categoria);
    }

    private void atualizar() {
        listar();
        int id = console.lerInteiro("Id da categoria: ");
        Categoria atual = service.buscarPorId(id);
        String nome = console.lerTexto("Novo nome (" + atual.getNome() + "): ");
        Categoria categoria = service.atualizar(id, nome);
        console.sucesso("Categoria atualizada: " + categoria);
    }

    private void excluir() {
        listar();
        int id = console.lerInteiro("Id da categoria: ");
        service.excluir(id);
        console.sucesso("Categoria excluida.");
    }
}
