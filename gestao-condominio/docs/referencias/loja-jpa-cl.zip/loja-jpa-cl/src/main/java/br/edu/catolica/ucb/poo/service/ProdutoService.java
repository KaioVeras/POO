package br.edu.catolica.ucb.poo.service;

import br.edu.catolica.ucb.poo.model.Categoria;
import br.edu.catolica.ucb.poo.model.Produto;
import br.edu.catolica.ucb.poo.repository.ProdutoRepository;

import java.math.BigDecimal;
import java.util.List;

public class ProdutoService {

    private final ProdutoRepository repository = new ProdutoRepository();
    private final CategoriaService categoriaService = new CategoriaService();

    public List<Produto> listar() {
        return repository.listar();
    }

    public Produto buscarPorId(Integer id) {
        Produto produto = repository.buscarPorId(id);
        if (produto == null) {
            throw new IllegalArgumentException("Produto com id " + id + " nao encontrado.");
        }
        return produto;
    }

    public Produto cadastrar(String nome, BigDecimal preco, Integer categoriaId) {
        validar(nome, preco);
        Categoria categoria = categoriaService.buscarPorId(categoriaId);
        return repository.salvar(new Produto(nome.trim(), preco, categoria));
    }

    public Produto atualizar(Integer id, String nome, BigDecimal preco, Integer categoriaId) {
        validar(nome, preco);
        Produto produto = buscarPorId(id);
        produto.setNome(nome.trim());
        produto.setPreco(preco);
        produto.setCategoria(categoriaService.buscarPorId(categoriaId));
        return repository.atualizar(produto);
    }

    public void excluir(Integer id) {
        buscarPorId(id);
        repository.excluir(id);
    }

    private void validar(String nome, BigDecimal preco) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome do produto e obrigatorio.");
        }
        if (nome.trim().length() > 100) {
            throw new IllegalArgumentException("O nome do produto deve ter no maximo 100 caracteres.");
        }
        if (preco == null || preco.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("O preco deve ser maior que zero.");
        }
    }
}
