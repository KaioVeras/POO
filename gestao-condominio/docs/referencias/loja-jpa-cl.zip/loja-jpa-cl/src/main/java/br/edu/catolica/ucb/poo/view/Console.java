package br.edu.catolica.ucb.poo.view;

import java.math.BigDecimal;
import java.util.Scanner;

public class Console {

    private final Scanner scanner = new Scanner(System.in);

    public String lerTexto(String rotulo) {
        System.out.print(rotulo);
        if (!scanner.hasNextLine()) {
            return "0";
        }
        return scanner.nextLine().trim();
    }

    public int lerInteiro(String rotulo) {
        while (true) {
            String valor = lerTexto(rotulo);
            try {
                return Integer.parseInt(valor);
            } catch (NumberFormatException e) {
                System.out.println("Valor invalido. Digite um numero inteiro.");
            }
        }
    }

    public BigDecimal lerDecimal(String rotulo) {
        while (true) {
            String valor = lerTexto(rotulo).replace(",", ".");
            try {
                return new BigDecimal(valor);
            } catch (NumberFormatException e) {
                System.out.println("Valor invalido. Exemplo: 19.90");
            }
        }
    }

    public void titulo(String texto) {
        System.out.println();
        System.out.println("=== " + texto + " ===");
    }

    public void sucesso(String mensagem) {
        System.out.println("OK: " + mensagem);
    }

    public void erro(String mensagem) {
        System.out.println("ERRO: " + mensagem);
    }
}
