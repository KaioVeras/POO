package br.edu.catolica.ucb.poo.repository;

import br.edu.catolica.ucb.poo.model.Categoria;
import br.edu.catolica.ucb.poo.util.JPAUtil;
import jakarta.persistence.EntityManager;

import java.util.List;

public class CategoriaRepository {

    public List<Categoria> listar() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.createQuery("SELECT c FROM Categoria c ORDER BY c.id", Categoria.class)
                    .getResultList();
        } finally {
            em.close();
        }
    }

    public Categoria buscarPorId(Integer id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.find(Categoria.class, id);
        } finally {
            em.close();
        }
    }

    public long contarProdutos(Integer categoriaId) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.createQuery("SELECT COUNT(p) FROM Produto p WHERE p.categoria.id = :id", Long.class)
                    .setParameter("id", categoriaId)
                    .getSingleResult();
        } finally {
            em.close();
        }
    }

    public Categoria salvar(Categoria categoria) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(categoria);
            em.getTransaction().commit();
            return categoria;
        } catch (RuntimeException e) {
            desfazer(em);
            throw e;
        } finally {
            em.close();
        }
    }

    public Categoria atualizar(Categoria categoria) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Categoria atualizada = em.merge(categoria);
            em.getTransaction().commit();
            return atualizada;
        } catch (RuntimeException e) {
            desfazer(em);
            throw e;
        } finally {
            em.close();
        }
    }

    public void excluir(Integer id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Categoria categoria = em.find(Categoria.class, id);
            if (categoria != null) {
                em.remove(categoria);
            }
            em.getTransaction().commit();
        } catch (RuntimeException e) {
            desfazer(em);
            throw e;
        } finally {
            em.close();
        }
    }

    private void desfazer(EntityManager em) {
        if (em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
    }
}
