package br.edu.catolica.ucb.poo.view;

import br.edu.catolica.ucb.poo.model.Produto;
import br.edu.catolica.ucb.poo.service.ProdutoService;

import java.math.BigDecimal;
import java.util.List;

public class ProdutoView {

    private final Console console;
    private final CategoriaView categoriaView;
    private final ProdutoService service = new ProdutoService();

    public ProdutoView(Console console, CategoriaView categoriaView) {
        this.console = console;
        this.categoriaView = categoriaView;
    }

    public void exibir() {
        int opcao;
        do {
            console.titulo("PRODUTOS");
            System.out.println("1 - Listar");
            System.out.println("2 - Cadastrar");
            System.out.println("3 - Atualizar");
            System.out.println("4 - Excluir");
            System.out.println("0 - Voltar");
            opcao = console.lerInteiro("Opcao: ");
            executar(opcao);
        } while (opcao != 0);
    }

    private void executar(int opcao) {
        try {
            switch (opcao) {
                case 1 -> listar();
                case 2 -> cadastrar();
                case 3 -> atualizar();
                case 4 -> excluir();
                case 0 -> { }
                default -> console.erro("Opcao invalida.");
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            console.erro(e.getMessage());
        } catch (RuntimeException e) {
            console.erro("Falha ao acessar o banco de dados: " + e.getMessage());
        }
    }

    private void listar() {
        List<Produto> produtos = service.listar();
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }
        produtos.forEach(System.out::println);
    }

    private void cadastrar() {
        String nome = console.lerTexto("Nome: ");
        BigDecimal preco = console.lerDecimal("Preco: ");
        System.out.println("Categorias disponiveis:");
        categoriaView.listar();
        int categoriaId = console.lerInteiro("Id da categoria: ");
        Produto produto = service.cadastrar(nome, preco, categoriaId);
        console.sucesso("Produto cadastrado: " + produto);
    }

    private void atualizar() {
        listar();
        int id = console.lerInteiro("Id do produto: ");
        Produto atual = service.buscarPorId(id);
        String nome = console.lerTexto("Novo nome (" + atual.getNome() + "): ");
        BigDecimal preco = console.lerDecimal("Novo preco (" + atual.getPreco() + "): ");
        System.out.println("Categorias disponiveis:");
        categoriaView.listar();
        int categoriaId = console.lerInteiro("Id da categoria (" + atual.getCategoria().getId() + "): ");
        Produto produto = service.atualizar(id, nome, preco, categoriaId);
        console.sucesso("Produto atualizado: " + produto);
    }

    private void excluir() {
        listar();
        int id = console.lerInteiro("Id do produto: ");
        service.excluir(id);
        console.sucesso("Produto excluido.");
    }
}
