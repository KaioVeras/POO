package br.edu.catolica.ucb.poo.service;

import br.edu.catolica.ucb.poo.model.Categoria;
import br.edu.catolica.ucb.poo.repository.CategoriaRepository;

import java.util.List;

public class CategoriaService {

    private final CategoriaRepository repository = new CategoriaRepository();

    public List<Categoria> listar() {
        return repository.listar();
    }

    public Categoria buscarPorId(Integer id) {
        Categoria categoria = repository.buscarPorId(id);
        if (categoria == null) {
            throw new IllegalArgumentException("Categoria com id " + id + " nao encontrada.");
        }
        return categoria;
    }

    public Categoria cadastrar(String nome) {
        validarNome(nome);
        return repository.salvar(new Categoria(nome.trim()));
    }

    public Categoria atualizar(Integer id, String novoNome) {
        validarNome(novoNome);
        Categoria categoria = buscarPorId(id);
        categoria.setNome(novoNome.trim());
        return repository.atualizar(categoria);
    }

    public void excluir(Integer id) {
        buscarPorId(id);
        if (repository.contarProdutos(id) > 0) {
            throw new IllegalStateException("Nao e possivel excluir: existem produtos nesta categoria.");
        }
        repository.excluir(id);
    }

    private void validarNome(String nome) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome da categoria e obrigatorio.");
        }
        if (nome.trim().length() > 100) {
            throw new IllegalArgumentException("O nome da categoria deve ter no maximo 100 caracteres.");
        }
    }
}
