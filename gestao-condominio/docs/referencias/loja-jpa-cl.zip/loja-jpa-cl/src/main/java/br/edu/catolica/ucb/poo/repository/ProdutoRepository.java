package br.edu.catolica.ucb.poo.repository;

import br.edu.catolica.ucb.poo.model.Produto;
import br.edu.catolica.ucb.poo.util.JPAUtil;
import jakarta.persistence.EntityManager;

import java.util.List;

public class ProdutoRepository {

    public List<Produto> listar() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.createQuery("SELECT p FROM Produto p JOIN FETCH p.categoria ORDER BY p.id", Produto.class)
                    .getResultList();
        } finally {
            em.close();
        }
    }

    public Produto buscarPorId(Integer id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.createQuery("SELECT p FROM Produto p JOIN FETCH p.categoria WHERE p.id = :id", Produto.class)
                    .setParameter("id", id)
                    .getResultStream()
                    .findFirst()
                    .orElse(null);
        } finally {
            em.close();
        }
    }

    public Produto salvar(Produto produto) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(produto);
            em.getTransaction().commit();
            return produto;
        } catch (RuntimeException e) {
            desfazer(em);
            throw e;
        } finally {
            em.close();
        }
    }

    public Produto atualizar(Produto produto) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Produto atualizado = em.merge(produto);
            em.getTransaction().commit();
            return atualizado;
        } catch (RuntimeException e) {
            desfazer(em);
            throw e;
        } finally {
            em.close();
        }
    }

    public void excluir(Integer id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Produto produto = em.find(Produto.class, id);
            if (produto != null) {
                em.remove(produto);
            }
            em.getTransaction().commit();
        } catch (RuntimeException e) {
            desfazer(em);
            throw e;
        } finally {
            em.close();
        }
    }

    private void desfazer(EntityManager em) {
        if (em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
    }
}
