package br.edu.catolica.ucb.poo.view;

public class MenuPrincipal {

    private final Console console = new Console();
    private final CategoriaView categoriaView = new CategoriaView(console);
    private final ProdutoView produtoView = new ProdutoView(console, categoriaView);

    public void exibir() {
        int opcao;
        do {
            console.titulo("MENU PRINCIPAL");
            System.out.println("1 - Produtos");
            System.out.println("2 - Categorias");
            System.out.println("0 - Sair");
            opcao = console.lerInteiro("Opcao: ");
            switch (opcao) {
                case 1 -> produtoView.exibir();
                case 2 -> categoriaView.exibir();
                case 0 -> System.out.println("Ate logo!");
                default -> console.erro("Opcao invalida.");
            }
        } while (opcao != 0);
    }
}
